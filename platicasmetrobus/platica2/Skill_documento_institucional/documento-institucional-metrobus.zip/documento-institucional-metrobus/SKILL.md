---
name: documento-institucional-metrobus
description: Crea documentos Word (.docx) con la plantilla institucional de Metrobús CDMX (encabezado con logos, colores y pie de página). Úsalo cuando se pida un informe, oficio, minuta, ficha técnica, reporte o cualquier documento institucional de Metrobús.
---

# Documento institucional Metrobús

Genera documentos Word con la imagen institucional de Metrobús de la Ciudad de México.

## Cuándo usarlo
Siempre que la persona pida un documento institucional: informe, reporte semanal, oficio, minuta, ficha técnica, nota informativa o cuestionario para Metrobús.

## Formato obligatorio
- **Encabezado:** la imagen `assets/encabezado.png` (logos del Gobierno de la Ciudad de México, Movilidad Integrada y Metrobús), alineada a la izquierda, de 16 cm de ancho, en todas las páginas. No la deformes ni la recortes.
- **Pie de página:** "Metrobús · Gobierno de la Ciudad de México" a la izquierda y el número de página a la derecha, en gris (#5A5A5A), 8 pt.
- **Tipografía:** Arial (o Source Sans Pro si está instalada). Texto 11 pt.
- **Título:** 18 pt, negritas, rojo Metrobús #C8102E. Debajo, una línea con la fecha y el área en gris.
- **Subtítulos:** 13 pt, negritas, rojo #C8102E.
- **Tablas:** encabezado con fondo rojo #C8102E y texto blanco; bordes gris claro.
- **Página:** tamaño carta, márgenes de 2.5 cm.

## Cómo hacerlo
1. Redacta el contenido en español claro, con títulos cortos.
2. Ejecuta `scripts/crear_documento.py` pasándole un archivo JSON con el contenido (ver el formato al inicio del script). Si falta la librería, instálala con `pip install python-docx`.
3. Guarda el archivo con un nombre descriptivo, por ejemplo `Informe_hallazgos_Linea1.docx`, en la carpeta de trabajo.
4. Revisa el resultado: el encabezado debe verse en todas las páginas.

## Reglas
- No inventes cifras: usa solo datos que la persona proporcionó o que salgan de sus archivos.
- Si el documento usa datos ficticios o de práctica, agrega al final: "Nota: datos ficticios con fines didácticos".
- No incluyas datos personales (nombres de personas usuarias, teléfonos, correos).
