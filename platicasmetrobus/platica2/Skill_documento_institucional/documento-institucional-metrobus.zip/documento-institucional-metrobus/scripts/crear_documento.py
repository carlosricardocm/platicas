# -*- coding: utf-8 -*-
"""
Crea un documento Word con la plantilla institucional de Metrobús.

Uso:
    python crear_documento.py contenido.json salida.docx

Formato de contenido.json:
{
  "titulo": "Informe de hallazgos · Línea 1",
  "subtitulo": "Dirección de Operación · noviembre de 2026",
  "bloques": [
    {"tipo": "h", "texto": "1. Resumen"},
    {"tipo": "p", "texto": "Texto del párrafo. Usa **negritas** si hace falta."},
    {"tipo": "lista", "items": ["Punto uno", "Punto dos"]},
    {"tipo": "tabla", "encabezados": ["Indicador", "Valor"], "filas": [["Satisfacción", "6.7"]]},
    {"tipo": "nota", "texto": "Nota: datos ficticios con fines didácticos."}
  ]
}
"""
import json, os, re, sys
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROJO, GRIS = RGBColor(0xC8, 0x10, 0x2E), RGBColor(0x5A, 0x5A, 0x5A)
AQUI = os.path.dirname(os.path.abspath(__file__))
ENCABEZADO = os.path.join(AQUI, "..", "assets", "encabezado.png")


def texto_con_negritas(par, texto, **fmt):
    for parte in re.split(r"(\*\*[^*]+\*\*)", texto):
        if not parte:
            continue
        r = par.add_run(parte[2:-2] if parte.startswith("**") else parte)
        r.bold = parte.startswith("**") or fmt.get("bold", False)
        if "size" in fmt: r.font.size = Pt(fmt["size"])
        if "color" in fmt: r.font.color.rgb = fmt["color"]


def sombrear(celda, color):
    tcPr = celda._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd"); shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), color)
    tcPr.append(shd)


def numero_de_pagina(par):
    r = par.add_run()
    for tag, txt in (("begin", None), (None, "PAGE"), ("end", None)):
        if tag:
            e = OxmlElement("w:fldChar"); e.set(qn("w:fldCharType"), tag)
        else:
            e = OxmlElement("w:instrText"); e.set(qn("xml:space"), "preserve"); e.text = txt
        r._r.append(e)
    r.font.size = Pt(8); r.font.color.rgb = GRIS


def crear(contenido, salida):
    doc = Document()
    st = doc.styles["Normal"]; st.font.name = "Arial"; st.font.size = Pt(11)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.59), Cm(27.94)
    for m in ("left_margin", "right_margin", "bottom_margin"): setattr(sec, m, Cm(2.5))
    sec.top_margin = Cm(3.2); sec.header_distance = Cm(1.0)
    # Encabezado con logos
    hp = sec.header.paragraphs[0]
    hp.add_run().add_picture(ENCABEZADO, width=Cm(16))
    # Pie de página
    fp = sec.footer.paragraphs[0]
    r = fp.add_run("Metrobús · Gobierno de la Ciudad de México\t\t"); r.font.size = Pt(8); r.font.color.rgb = GRIS
    numero_de_pagina(fp)
    # Título
    t = doc.add_paragraph(); texto_con_negritas(t, contenido.get("titulo", "Documento"), bold=True, size=18, color=ROJO)
    if contenido.get("subtitulo"):
        s = doc.add_paragraph(); texto_con_negritas(s, contenido["subtitulo"], size=10, color=GRIS)
    for b in contenido.get("bloques", []):
        tipo = b.get("tipo", "p")
        if tipo == "h":
            p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12)
            texto_con_negritas(p, b["texto"], bold=True, size=13, color=ROJO)
        elif tipo == "p":
            texto_con_negritas(doc.add_paragraph(), b["texto"])
        elif tipo == "lista":
            for it in b["items"]:
                texto_con_negritas(doc.add_paragraph(style="List Bullet"), it)
        elif tipo == "tabla":
            enc, filas = b["encabezados"], b["filas"]
            tb = doc.add_table(rows=1 + len(filas), cols=len(enc)); tb.style = "Table Grid"
            for j, h in enumerate(enc):
                c = tb.rows[0].cells[j]; c.text = ""; sombrear(c, "C8102E")
                texto_con_negritas(c.paragraphs[0], str(h), bold=True, size=10, color=RGBColor(0xFF, 0xFF, 0xFF))
            for i, fila in enumerate(filas, 1):
                for j, v in enumerate(fila):
                    c = tb.rows[i].cells[j]; c.text = ""; texto_con_negritas(c.paragraphs[0], str(v), size=10)
            # Anchos de columna proporcionales al texto más largo (total 16.5 cm)
            largos = [max([len(str(h))] + [len(str(f[j])) for f in filas]) for j, h in enumerate(enc)]
            largos = [min(max(l, 6), 60) for l in largos]
            tot = sum(largos); tb.autofit = False
            for j, l in enumerate(largos):
                tb.columns[j].width = Cm(16.5 * l / tot)
                for fila_t in tb.rows:
                    fila_t.cells[j].width = Cm(16.5 * l / tot)
            doc.add_paragraph()
        elif tipo == "nota":
            p = doc.add_paragraph(); texto_con_negritas(p, b["texto"], size=9, color=GRIS)
    doc.save(salida)
    print("Documento creado:", salida)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("Uso: python crear_documento.py contenido.json salida.docx")
    crear(json.load(open(sys.argv[1], encoding="utf-8")), sys.argv[2])
